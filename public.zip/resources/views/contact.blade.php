<!DOCTYPE html>
<html>
<head>
    <title>Laravel domaci</title>
</head>
<body>
Dobrodosli na Contact Stranicu!
</body>
</html>
