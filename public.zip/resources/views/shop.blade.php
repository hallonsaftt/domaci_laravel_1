<!DOCTYPE html>
<html>
<head>
    <title>Laravel domaci</title>
</head>
<body>
Dobrodosli na Shop Stranicu!
</body>
</html>
