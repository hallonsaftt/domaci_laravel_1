<!DOCTYPE html>
<html>
    <head>
        <title>Laravel domaci</title>
    </head>
    <body>
       Dobrodosli na Welcome Stranicu!
    </body>
</html>
