<!DOCTYPE html>
<html>
<head>
    <title>Laravel domaci</title>
</head>
<body>
Dobrodosli na Contact Stranicu!
</body>
</html>
<?php /**PATH I:\Xampp25\htdocs\domaci_1\resources\views/contact.blade.php ENDPATH**/ ?>