<!DOCTYPE html>
<html>
    <head>
        <title>Laravel domaci</title>
    </head>
    <body>
       Dobrodosli na Welcome Stranicu!
    </body>
</html>
<?php /**PATH I:\Xampp25\htdocs\domaci_1\resources\views/welcome.blade.php ENDPATH**/ ?>