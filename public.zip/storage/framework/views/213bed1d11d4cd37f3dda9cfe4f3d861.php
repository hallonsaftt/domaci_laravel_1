<!DOCTYPE html>
<html>
<head>
    <title>Laravel domaci</title>
</head>
<body>
Dobrodosli na Shop Stranicu!
</body>
</html>
<?php /**PATH I:\Xampp25\htdocs\domaci_1\resources\views/shop.blade.php ENDPATH**/ ?>