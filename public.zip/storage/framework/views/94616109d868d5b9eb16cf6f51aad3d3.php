<!DOCTYPE html>
<html>
<head>
    <title>Laravel domaci</title>
</head>
<body>
Dobrodosli na About Stranicu!
</body>
</html>
<?php /**PATH I:\Xampp25\htdocs\domaci_1\resources\views/about.blade.php ENDPATH**/ ?>